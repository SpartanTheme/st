compass-phpsass
===============

Hi all,
this is a Compass Sass Framework http://compass-style.org for Phpsass based on the Compass extension integrated in Sassy for Drupal http://drupalcode.org/project/sassy.git/tree/HEAD:/extensions/compass
I only removed the specific code for Drupal and chaged it to Classes instead of *.module and *.inc

I hope that you enjoy.

Juan Manuel Vergés Solanas.
